<?php


$website_name="



عيادات اللؤلؤ
";

$dr_name="


";

$phone_main="966567643642";

$action_url="https://script.google.com/macros/s/AKfycbwtz5HmSyvsXtVjm5rTNGgATWVkjoYFAvEoWSQpwnXgN8FkTm1N-948ehdi40KhZhaj/exec";

$sheet_url="https://docs.google.com/spreadsheets/d/15ubpqR4FwRw27laCgA71Ob6Xp1SkHgMdULFDnKpRbqo/edit?usp=sharing";

$form1_des="
احجز الان
";
$cta=0;
$cta_text="احجز الان ";
$form1_des2="


واحصل على استشارة تسويقية مجانا 

";


$form2_des="

قم بتعبئة البيانات

";


$form2_des2="

وسيتم تحويلك الى واتساب مباشرة

";




$footer_des1="

قمة الإنتشار للتسويق الإلكتروني  

";



$footer_des2="

 

";



$footer_des3="

سجل تجاري رقم 

 <br>
2051251848
<br>
<a href= 'mailto:info@intshar.net' style='color: white;'>info@intshar.net</a>

<br>

<a href='tel:'.$phone_main.' style='color: white;'>$phone_main</a>

<br>
المملكة العربية السعودية-الخبر
";



$footer_des4="

المملكة العربية السعودية-الخبر

";








$before_after=0;
$services=0;
$derma_services=0;
$services2=0;
$faq=0;
$process=0;
$services_images=0;
$footer=0;
$w_app_button=0;
$api_notification=0;
$ad_source="snap ";
$header1=1;
$parteners=0;
$about_image=0;



?>