<?php

 


 

$website_name="


الشبكة الأولى
 
";

$dr_name="

 
أقوى الخصومات في جميع المجالات

 


";



$phone_main="966537199787";

$action_url="https://script.google.com/macros/s/AKfycbxOGMoBb2wzOYJ1rlf69c6qd4PG4eyepU4qQkP9ZHO-_RvsUHuV5ESWu37WugFdYZ-L/exec";

$sheet_url="https://script.google.com/macros/s/AKfycbzYXkjDojvTSa8eR0w9GK1EQLDFrAH2ODophKmQEWoht87BCmbDCIkY-nORgQ5fs_0A/exec";

$map_url="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3571.6468240829295!2d50.06192668496448!3d26.467110983321493!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e49fe7d7ecf2d03%3A0xea296fa9e509bf1e!2z2YXYrNmF2Lkg2KfZhNi52YrYp9iv2Kkg2KfZhNiq2KfYs9i52Kkg2KfZhNis2K_ZitivINin2YTYt9io2Yo!5e0!3m2!1sar!2ssa!4v1722380801558!5m2!1sar!2ssa";





$form1_des="

العرض ساري لمدة 24 ساعة فقط
";
$cta=0;
$cta_text="احجز الان";
$form1_des2="

سجل بياناتك وسيتم التواصل معك لشرح كل مميزات بطاقتنا السحرية 
";

$form1_des3="


 

";





$form2_des="

قم بتعبئة البيانات

";


$form2_des2="

وسيتم تحويلك الى واتساب مباشرة

";




$footer_des1="

قمة الإنتشار للتسويق الإلكتروني  

";



$footer_des2="

 

";



$footer_des3="

سجل تجاري رقم 

 <br>
2051251848
<br>
<a href= 'mailto:info@intshar.net' style='color: white;'>info@intshar.net</a>

<br>

<a href='tel:'.$phone_main.' style='color: white;'>$phone_main</a>

<br>
المملكة العربية السعودية-الخبر
";



$footer_des4="

المملكة العربية السعودية-الخبر

";








$before_after=0;
$map=0;
$services=0;
$derma_services=0;
$services2=0;
$faq=0;
$process=0;
$services_images=0;
$footer=1;
$footer2=0;
$w_app_button=1;
$api_notification=1;
$ad_source="meta ";
$header1=1;
$parteners=0;
$about_image=0;

$services_list=0;
$taby_and_tamara=1;


?>