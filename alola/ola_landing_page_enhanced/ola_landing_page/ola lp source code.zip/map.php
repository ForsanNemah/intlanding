 
  <div class="container my-5" data-aos-duration="1500" data-aos="zoom-in-up">
    <div class="row">
      <div class="col-12">
        <div class="ratio ratio-16x9">
          <iframe src="<?php echo $map_url ?>" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
      </div>
    </div>
  </div>
  