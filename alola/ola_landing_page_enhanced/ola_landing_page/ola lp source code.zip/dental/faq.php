
<div class="container mt-4">
  <div class="row justify-content-center">
    <div class="col-lg-8 text-center">
      <h1 style="color: green;">
    
    
      أسئلة شائعة
    
    
    
    </h1>
      <div class="accordion" id="faqAccordion">
        <!-- Accordion items go here -->
      </div>
    </div>
  </div>
</div>









<div class="container">
  <div class="row justify-content-center">
    <div class="col-lg-8">
      <div class="accordion" id="faqAccordion">


       



















        <div class="accordion-item">
          <h2 class="accordion-header" id="headingOne">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
            ما هو الفرق بين الفينيير والزيركون ؟
            </button>
          </h2>
          <div id="collapseOne" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#faqAccordion">
            <div class="accordion-body">
            يشتهر الفينيير بانه يستخدم مادة البورسلين او الخزف والمقصود بالزيركون في السؤال استخدام مادة الزيركون للفينيير ،والفرق ان الزيركون طويل الامد اضافة الى جماليته التي تضاهي الاسنان الطبيعية
            </div>
          </div>
        </div>








        <div class="accordion-item">
          <h2 class="accordion-header" id="headingTwo">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            ما هو الفرق بين الفينيير والزيركون ؟
            </button>
          </h2>
          <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
            <div class="accordion-body">
            يشتهر الفينيير بانه يستخدم مادة البورسلين او الخزف والمقصود بالزيركون في السؤال استخدام مادة الزيركون للفينيير ،والفرق ان الزيركون طويل الامد اضافة الى جماليته التي تضاهي الاسنان الطبيعية
            </div>
          </div>
        </div>





  
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingthree">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
            ما هي زراعة الاسنان الفورية؟
            </button>
          </h2>
          <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
            <div class="accordion-body">
   

            زراعة الاسنان الفورية او زراعة اليوم الواحد بشكل مبسط تهدف الى تركيب الاسنان بنفس يوم الزراعة وهو الامر الذي يعني المريض من الحرج من عدم وجود الاسنان



            </div>
          </div>
        </div>










  
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingfour">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefour" aria-expanded="false" aria-controls="collapseTwo">
            هل زراعة الاسنان مؤلمة؟
            </button>
          </h2>
          <div id="collapsefour" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
            <div class="accordion-body">
            في معظم الحالات تتسبب عملية زرع الاسنان نفسها بالم بسيط جدا للمريض ولكن بمجرد زوال المخدر غالبا ما يشعر المريض بقدر من الانزعاج
            </div>
          </div>
        </div>





          
        <div class="accordion-item">
          <h2 class="accordion-header" id="headingfive">
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsefive" aria-expanded="false" aria-controls="collapseTwo">
            متى يلزم تقويم الاسنان؟
            </button>
          </h2>
          <div id="collapsefive" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#faqAccordion">
            <div class="accordion-body">
 
            في حال وجود مشاكل معينة في النطق او مشكلة في اطباق الاسنان او وجود مسافة زائدة بين الاسنان من تداخل او اعوجاج
            </div>
          </div>
        </div>










        <!-- Add more accordion items as needed -->
      </div>
    </div>
  </div>
</div>



<style>


.accordion-button {

    font-weight:1000;
    position: relative;
    display: flex;
    align-items: center;
    width: 100%;
    padding: 1rem 1.25rem;
    font-size: 1rem;
    color: #8ebb46;
    text-align: left;
    background-color: #fff7f7;
    border: 1px solid rgba(0, 0, 0, .125);
    border-radius: 0;
    overflow-anchor: none;
    transition: color .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out, border-radius .15s ease;
}


</style>