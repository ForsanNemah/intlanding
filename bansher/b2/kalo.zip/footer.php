
    <!-- Footer -->
    <footer class="page-footer font-small blue">
    
<!-- Copyright -->
 

<div class="footer-copyright text-center py-3">    
    <a style="color:blue;" href="https://wmc-ksa.com/">شركة النافذة للتسويق الالكتروني </a>
 
 

   
</div>
<!-- Copyright -->


<div class="footer-copyright text-center py-3">    
 
 
 <a style="color:blue;" href="privicy.php">سياسة الخصوصية  </a>

   
</div>

</footer>