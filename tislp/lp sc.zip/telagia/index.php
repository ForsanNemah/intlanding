<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>

    <?php

include "info.php";
include "header.php";
include "floating.php";
?>


</head>
<body>
    <!-- Hero Section -->
     
 <?php

include "hero.php";
include "form.php";

?>
    <!-- About Us Section -->
   <?php


include "about.php";
//include "offers.php";



?>

    <!-- Services Section -->
     

    <?php

//include "services.php";

?>

    <!-- Before & After Section -->

      <?php

//include "bafter.php";

?>
    
    <!-- Offers Section -->
      

    <!-- Footer -->
      <?php

include "footer.php";

?>

    <!-- Floating Buttons -->
   

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JavaScript -->
    <script src="script.js"></script>
</body>
</html>

