<section id="before-after" class="before-after-section py-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 text-center">
        <h2 class="section-title">   
            
    العروض
    
    </h2>
        <div class="section-divider"></div>
      </div>
    </div>
    <div class="row g-4 mt-4">

      <!-- صورة قبل العلاج -->
      <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/filer1.jpg" alt="قبل العلاج"
             style="width:100%; height:auto;" class="rounded shadow">
       
      </div>

      <!-- صورة بعد العلاج -->
   


       


        <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/filer4.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">

      </div>

        <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/filer5.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">
      </div>


       <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/face1.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">
      </div>



       <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/tato1.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">
      </div>



      
       <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/nose1.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">
      </div>

<!-- 
       <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/filer2.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">

      </div>



       <div class="col-lg-6 col-md-6 text-center">
        <img src="bafter/filer2.jpg" alt="بعد العلاج"
             style="width:100%; height:auto;" class="rounded shadow">

      </div> -->




    </div>
  </div>
</section>
