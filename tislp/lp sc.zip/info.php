<?php






 
$page_titel=" مجمع تداوي الطبي ";
$place_name=" مجمع تداوي الطبي ";
$adress=" السعودية-الطائف";
$w_app_number="966543442624";
$call_number="966543442624";
$email="info@tadawis.com";
$insta_url="https://www.instagram.com/tadawicenter/";




$about ="

نسعى لتقديم أحدث التقنيات كأول مجمع طبي في الطائف

بخدمات راقية بتقسيط مريح
";

$ad_main_title="عروض اليوم الوطني 95 من مجمع تداوي";

?>